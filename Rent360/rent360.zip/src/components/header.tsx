'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Building, Menu, X, LogIn, User, LogOut } from 'lucide-react';
import { User as UserType } from '@/types';

function convertDatesToObjects(user: any): UserType {
  return {
    ...user,
    createdAt: new Date(user.createdAt),
    updatedAt: new Date(user.updatedAt)
  };
}

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [user, setUser] = useState<UserType | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await fetch('/api/auth/me');
      if (response.ok) {
        const data = await response.json();
        const userWithDates = convertDatesToObjects(data.user);
        setUser(userWithDates);
      } else if (response.status === 401) {
        // User not authenticated, this is normal
        setUser(null);
      } else {
        setError('Error checking authentication status');
        setUser(null);
      }
    } catch (error) {
      console.error('Error checking auth:', error);
      setError('Network error checking authentication');
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      const response = await fetch('/api/auth/logout', {
        method: 'POST',
      });
      
      if (response.ok) {
        setUser(null);
        // Clear any stored user data
        localStorage.removeItem('user');
        router.push('/');
      } else {
        console.error('Logout failed');
      }
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const getDashboardUrl = (role: string) => {
    switch (role) {
      case 'admin': return '/admin/dashboard';
      case 'tenant': return '/tenant/dashboard';
      case 'owner': return '/owner/dashboard';
      case 'broker': return '/broker/dashboard';
      case 'runner': return '/runner/dashboard';
      case 'support': return '/support/dashboard';
      default: return '/';
    }
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-gray-200">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <Building className="w-8 h-8 text-emerald-600" />
            <span className="text-xl font-bold text-gray-900">Rent360</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 hover:text-emerald-600 transition-colors">
              Inicio
            </Link>
            <Link href="/properties/search" className="text-gray-700 hover:text-emerald-600 transition-colors">
              Buscar Propiedades
            </Link>
            <Link href="/about" className="text-gray-700 hover:text-emerald-600 transition-colors">
              Nosotros
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-emerald-600 transition-colors">
              Contacto
            </Link>
          </nav>

          {/* Auth Buttons - Always visible */}
          <div className="flex items-center space-x-2">
            {isLoading ? (
              <div className="w-20 h-10 bg-gray-200 rounded animate-pulse"></div>
            ) : error ? (
              <div className="text-sm text-red-600">Error de conexión</div>
            ) : user ? (
              <>
                <Button asChild variant="outline" size="sm" className="hidden sm:flex">
                  <Link href={getDashboardUrl(user.role)}>
                    <User className="w-4 h-4 mr-2" />
                    Mi Panel
                  </Link>
                </Button>
                <Button onClick={handleLogout} variant="outline" size="sm" className="hidden sm:flex">
                  <LogOut className="w-4 h-4 mr-2" />
                  Cerrar Sesión
                </Button>
              </>
            ) : (
              <>
                <Button asChild className="bg-emerald-600 text-white hover:bg-emerald-700" size="sm">
                  <Link href="/auth/login">
                    <LogIn className="w-4 h-4 mr-2" />
                    Iniciar Sesión
                  </Link>
                </Button>
                <Button asChild variant="outline" size="sm" className="hidden sm:flex">
                  <Link href="/auth/register">
                    Registrarse
                  </Link>
                </Button>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="sm"
            className="md:hidden"
            onClick={toggleMenu}
          >
            {isMenuOpen ? (
              <X className="w-5 h-5" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-gray-200 py-4">
            <nav className="flex flex-col space-y-4">
              <Link 
                href="/" 
                className="text-gray-700 hover:text-emerald-600 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Inicio
              </Link>
              <Link 
                href="/properties/search" 
                className="text-gray-700 hover:text-emerald-600 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Buscar Propiedades
              </Link>
              <Link 
                href="/about" 
                className="text-gray-700 hover:text-emerald-600 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Nosotros
              </Link>
              <Link 
                href="/contact" 
                className="text-gray-700 hover:text-emerald-600 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Contacto
              </Link>
              <div className="flex flex-col space-y-2 pt-4 border-t border-gray-200">
                {isLoading ? (
                  <div className="w-full h-10 bg-gray-200 rounded animate-pulse"></div>
                ) : error ? (
                  <div className="text-sm text-red-600 text-center py-2">Error de conexión</div>
                ) : user ? (
                  <>
                    <Button asChild variant="outline" className="w-full">
                      <Link href={getDashboardUrl(user.role)} onClick={() => setIsMenuOpen(false)}>
                        <User className="w-4 h-4 mr-2" />
                        Mi Panel
                      </Link>
                    </Button>
                    <Button onClick={() => { handleLogout(); setIsMenuOpen(false); }} variant="outline" className="w-full">
                      <LogOut className="w-4 h-4 mr-2" />
                      Cerrar Sesión
                    </Button>
                  </>
                ) : (
                  <>
                    <Button asChild className="w-full bg-emerald-600 text-white hover:bg-emerald-700">
                      <Link href="/auth/register" onClick={() => setIsMenuOpen(false)}>
                        Registrarse
                      </Link>
                    </Button>
                  </>
                )}
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}