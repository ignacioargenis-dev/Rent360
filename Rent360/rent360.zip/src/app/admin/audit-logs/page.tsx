'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  FileText, 
  Search, 
  Filter, 
  Download, 
  Calendar,
  User as UserIcon,
  Shield,
  Database,
  Settings,
  AlertTriangle,
  CheckCircle,
  Eye,
  Activity,
  Clock,
  MapPin,
  Device,
  Building,
  DollarSign
} from 'lucide-react';
import Link from 'next/link';
import { User } from '@/types';
import EnhancedDashboardLayout from '@/components/dashboard/EnhancedDashboardLayout';

interface AuditLog {
  id: string;
  action: string;
  category: 'user' | 'property' | 'contract' | 'payment' | 'system' | 'security';
  userId: string;
  userName: string;
  userEmail: string;
  userRole: string;
  description: string;
  timestamp: string;
  ipAddress: string;
  device: string;
  location: string;
  severity: 'info' | 'warning' | 'error' | 'critical';
  status: 'success' | 'failed' | 'pending';
  details?: any;
}

interface AuditStats {
  totalLogs: number;
  todayLogs: number;
  failedAttempts: number;
  securityEvents: number;
  userActions: number;
  systemActions: number;
}

export default function AdminAuditLogs() {
  const [user, setUser] = useState<User | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [stats, setStats] = useState<AuditStats>({
    totalLogs: 0,
    todayLogs: 0,
    failedAttempts: 0,
    securityEvents: 0,
    userActions: 0,
    systemActions: 0
  });
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [dateRange, setDateRange] = useState('7d');

  useEffect(() => {
    const loadUserData = async () => {
      try {
        const response = await fetch('/api/auth/me');
        if (response.ok) {
          const data = await response.json();
          setUser(data.user);
        }
      } catch (error) {
        console.error('Error loading user data:', error);
      }
    };

    const loadAuditLogs = async () => {
      try {
        // Mock audit logs data for demonstration
        const mockAuditLogs: AuditLog[] = [
          {
            id: '1',
            action: 'login',
            category: 'user',
            userId: 'user123',
            userName: 'Juan Pérez',
            userEmail: 'juan@example.com',
            userRole: 'admin',
            description: 'Inicio de sesión exitoso',
            timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
            ipAddress: '192.168.1.100',
            device: 'Chrome on Windows',
            location: 'Santiago, Chile',
            severity: 'info',
            status: 'success'
          },
          {
            id: '2',
            action: 'property_create',
            category: 'property',
            userId: 'user456',
            userName: 'María García',
            userEmail: 'maria@example.com',
            userRole: 'owner',
            description: 'Creó nueva propiedad "Departamento Centro"',
            timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
            ipAddress: '192.168.1.101',
            device: 'Safari on macOS',
            location: 'Valparaíso, Chile',
            severity: 'info',
            status: 'success'
          },
          {
            id: '3',
            action: 'login_failed',
            category: 'security',
            userId: 'unknown',
            userName: 'Unknown',
            userEmail: '',
            userRole: '',
            description: 'Intento de inicio de sesión fallido - contraseña incorrecta',
            timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
            ipAddress: '192.168.1.200',
            device: 'Firefox on Linux',
            location: 'Unknown',
            severity: 'warning',
            status: 'failed'
          },
          {
            id: '4',
            action: 'payment_processed',
            category: 'payment',
            userId: 'user789',
            userName: 'Carlos López',
            userEmail: 'carlos@example.com',
            userRole: 'tenant',
            description: 'Procesó pago del contrato #123',
            timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
            ipAddress: '192.168.1.102',
            device: 'Mobile App on iOS',
            location: 'Concepción, Chile',
            severity: 'info',
            status: 'success'
          },
          {
            id: '5',
            action: 'system_update',
            category: 'system',
            userId: 'system',
            userName: 'System',
            userEmail: 'system@rent360.cl',
            userRole: 'system',
            description: 'Actualización automática del sistema completada',
            timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
            ipAddress: 'localhost',
            device: 'System Service',
            location: 'Server',
            severity: 'info',
            status: 'success'
          },
          {
            id: '6',
            action: 'permission_change',
            category: 'user',
            userId: 'user123',
            userName: 'Juan Pérez',
            userEmail: 'juan@example.com',
            userRole: 'admin',
            description: 'Modificó permisos del usuario user456',
            timestamp: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
            ipAddress: '192.168.1.100',
            device: 'Chrome on Windows',
            location: 'Santiago, Chile',
            severity: 'warning',
            status: 'success'
          },
          {
            id: '7',
            action: 'data_export',
            category: 'system',
            userId: 'user123',
            userName: 'Juan Pérez',
            userEmail: 'juan@example.com',
            userRole: 'admin',
            description: 'Exportó datos de usuarios y propiedades',
            timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
            ipAddress: '192.168.1.100',
            device: 'Chrome on Windows',
            location: 'Santiago, Chile',
            severity: 'info',
            status: 'success'
          },
          {
            id: '8',
            action: 'security_breach',
            category: 'security',
            userId: 'unknown',
            userName: 'Unknown',
            userEmail: '',
            userRole: '',
            description: 'Detección de actividad sospechosa - múltiples intentos de acceso',
            timestamp: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
            ipAddress: '192.168.1.300',
            device: 'Unknown Bot',
            location: 'Unknown',
            severity: 'critical',
            status: 'failed'
          }
        ];

        setAuditLogs(mockAuditLogs);

        // Calculate stats
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        const auditStats = mockAuditLogs.reduce((acc, log) => {
          acc.totalLogs++;
          
          const logDate = new Date(log.timestamp);
          if (logDate >= today) {
            acc.todayLogs++;
          }
          
          if (log.status === 'failed') {
            acc.failedAttempts++;
          }
          
          if (log.category === 'security') {
            acc.securityEvents++;
          }
          
          if (log.category === 'user' || log.category === 'property' || log.category === 'payment' || log.category === 'contract') {
            acc.userActions++;
          }
          
          if (log.category === 'system') {
            acc.systemActions++;
          }
          
          return acc;
        }, {
          totalLogs: 0,
          todayLogs: 0,
          failedAttempts: 0,
          securityEvents: 0,
          userActions: 0,
          systemActions: 0
        } as AuditStats);

        setStats(auditStats);
        setLoading(false);
      } catch (error) {
        console.error('Error loading audit logs:', error);
        setLoading(false);
      }
    };

    loadUserData();
    loadAuditLogs();
  }, [dateRange]);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'user':
        return <UserIcon className="w-5 h-5" />;
      case 'property':
        return <Building className="w-5 h-5" />;
      case 'contract':
        return <FileText className="w-5 h-5" />;
      case 'payment':
        return <DollarSign className="w-5 h-5" />;
      case 'system':
        return <Database className="w-5 h-5" />;
      case 'security':
        return <Shield className="w-5 h-5" />;
      default:
        return <Activity className="w-5 h-5" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'text-red-600 bg-red-50 border-red-200';
      case 'error':
        return 'text-red-600 bg-red-50 border-red-200';
      case 'warning':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'info':
        return 'text-blue-600 bg-blue-50 border-blue-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success':
        return 'bg-green-100 text-green-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'success':
        return <Badge className={getStatusColor(status)}>Éxito</Badge>;
      case 'failed':
        return <Badge className={getStatusColor(status)}>Fallido</Badge>;
      case 'pending':
        return <Badge className={getStatusColor(status)}>Pendiente</Badge>;
      default:
        return <Badge>Desconocido</Badge>;
    }
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <Badge className="bg-red-100 text-red-800">Crítico</Badge>;
      case 'error':
        return <Badge className="bg-red-100 text-red-800">Error</Badge>;
      case 'warning':
        return <Badge className="bg-yellow-100 text-yellow-800">Advertencia</Badge>;
      case 'info':
        return <Badge className="bg-blue-100 text-blue-800">Info</Badge>;
      default:
        return <Badge>Desconocido</Badge>;
    }
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString('es-CL', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const formatRelativeTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 60) return `Hace ${diffMins} minutos`;
    if (diffHours < 24) return `Hace ${diffHours} horas`;
    if (diffDays < 7) return `Hace ${diffDays} días`;
    
    return date.toLocaleDateString('es-CL');
  };

  const filteredAuditLogs = auditLogs.filter(log => {
    const matchesFilter = filter === 'all' || log.category === filter || log.severity === filter || log.status === filter;
    const matchesSearch = log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         log.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         log.userEmail.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Cargando registros de auditoría...</p>
        </div>
      </div>
    );
  }

  return (
    <EnhancedDashboardLayout
      user={user}
      title="Registros de Auditoría"
      subtitle="Monitorea todas las actividades del sistema"
    >
      <div className="container mx-auto px-4 py-6">
        {/* Header with stats */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Registros de Auditoría</h1>
            <p className="text-gray-600">Monitorea y analiza todas las actividades del sistema</p>
          </div>
          <div className="flex gap-2">
            <select 
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md text-sm"
            >
              <option value="24h">Últimas 24 horas</option>
              <option value="7d">Últimos 7 días</option>
              <option value="30d">Últimos 30 días</option>
              <option value="90d">Últimos 90 días</option>
            </select>
            <Button variant="outline" size="sm">
              <Filter className="w-4 h-4 mr-2" />
              Filtros
            </Button>
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Exportar
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4 mb-6">
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900">{stats.totalLogs}</p>
                <p className="text-xs text-gray-600">Total Registros</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">{stats.todayLogs}</p>
                <p className="text-xs text-gray-600">Hoy</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-red-600">{stats.failedAttempts}</p>
                <p className="text-xs text-gray-600">Intentos Fallidos</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-orange-600">{stats.securityEvents}</p>
                <p className="text-xs text-gray-600">Eventos Seguridad</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">{stats.userActions}</p>
                <p className="text-xs text-gray-600">Acciones Usuario</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-600">{stats.systemActions}</p>
                <p className="text-xs text-gray-600">Acciones Sistema</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Buscar registros..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="flex gap-2">
            <select 
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">Todas las categorías</option>
              <option value="user">Usuario</option>
              <option value="property">Propiedad</option>
              <option value="contract">Contrato</option>
              <option value="payment">Pago</option>
              <option value="system">Sistema</option>
              <option value="security">Seguridad</option>
            </select>
            <select 
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">Todas las severidades</option>
              <option value="critical">Crítico</option>
              <option value="error">Error</option>
              <option value="warning">Advertencia</option>
              <option value="info">Info</option>
            </select>
          </div>
        </div>

        {/* Audit Logs List */}
        <div className="space-y-4">
          {filteredAuditLogs.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">No se encontraron registros de auditoría</p>
                  <p className="text-sm text-gray-400">Intenta ajustar tus filtros de búsqueda</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            filteredAuditLogs.map((log) => (
              <Card 
                key={log.id} 
                className={`border-l-4 ${getSeverityColor(log.severity)}`}
              >
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3 flex-1">
                      <div className={`p-2 rounded-lg ${getSeverityColor(log.severity)}`}>
                        {getCategoryIcon(log.category)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-gray-900">{log.action}</h3>
                          {getStatusBadge(log.status)}
                          {getSeverityBadge(log.severity)}
                        </div>
                        <p className="text-gray-600 text-sm mb-2">{log.description}</p>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs text-gray-500">
                          <div className="flex items-center gap-1">
                            <User className="w-3 h-3" />
                            <span>{log.userName} ({log.userRole})</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>{formatRelativeTime(log.timestamp)}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            <span>{log.location}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Device className="w-3 h-3" />
                            <span>{log.device}</span>
                          </div>
                        </div>
                        
                        <div className="mt-2 text-xs text-gray-400">
                          <span>IP: {log.ipAddress}</span>
                          <span className="mx-2">•</span>
                          <span>{formatDateTime(log.timestamp)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 ml-4">
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </EnhancedDashboardLayout>
  );
}